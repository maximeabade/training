var searchData=
[
  ['choix_5fpi_0',['choix_pi',['../pi_8h.html#ad6ee9e6da3719416cfd52cd9a0a12e9e',1,'pi.h']]],
  ['choix_5fsqrt2_1',['choix_sqrt2',['../sqrt2_8h.html#a8c41b9a75c878358cc399655cbdafcab',1,'sqrt2.h']]]
];

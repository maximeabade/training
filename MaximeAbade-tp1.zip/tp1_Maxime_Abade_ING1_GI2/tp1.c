#include <stdio.h>
#include <stdlib.h>



/*
\file tp1.c, exectuable is tp1
\version 1.0
\author Maxime ABADE <abademaxim@cy-tech.fr>
\date 18/10/2022
\brief Simple "Hello World" output program

*/

int main(int argc, char** argv) {
    printf("Hello, World!\n");
    return(0);    
}

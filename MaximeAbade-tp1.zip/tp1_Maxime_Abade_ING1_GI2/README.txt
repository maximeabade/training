COMPILATION:
Entrez dans le terminal à l'emplacement du dossier, et tapez la commande suivante:
	gcc -Wall tp1.c -o tp1
	
EXÉCUTION:
Dans le même terminal, tapez la commande suivante:
	./tp1
	
DOXYGEN ET DOXYFILE:
Si le fichier de configuration Doxyfile n'existe pas, on le génère avec la commande suivante:
	doxygen -g
	
Après avoir configuré le fichier de configuration au cas d'utilisation, pour compiler la documentation, tapez la commande suivante:

	doxgen Doxyfile
	

